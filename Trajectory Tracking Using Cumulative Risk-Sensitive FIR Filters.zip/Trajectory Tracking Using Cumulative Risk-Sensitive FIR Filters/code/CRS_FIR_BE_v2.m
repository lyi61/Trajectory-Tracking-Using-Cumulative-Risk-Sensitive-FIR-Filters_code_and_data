%% ----------------Horizon为[k-N+1,k]----------------  后向欧拉 累加形式   与最开始不同地方是求解中直接用的IRS的估计值
%   x=Fx+Eu+Bw
%   y=Hx+v                          
%%
function x_CRS=CRS_FIR_BE_v2(F,E,B,H,Q,R,y,u,k,Nall,K,theta_CRS,theta_IRS) 

dim_x = size(F,1);            %%x维数
dim_y = size(H,1);            %%y维数
dim_u = size(E,2);            %%u维数
dim_w = size(B,2);            %%w维数
s = k-Nall+K;

ki = 0;
for  kIRS = s:k-1
     N_IRS = K + ki;
     ki=ki+1;
     x_IRS(:,kIRS) = IRS_FIR_BE(F,E,B,H,kIRS,N_IRS,y,u,Q,R,theta_IRS);
end

m = s;
N = Nall - K +1;
Y = [y(:,m)];
U = [u(:,m)];
for i = m+1:k                   %% 扩展状态空间方程参数
    Y = [Y ; y(:,i)];
    U = [U ; u(:,i)];
end

F_mk = F^0;
for i =1 : N-1
    F_mk = [F_mk ; F^i];
end

for j=1:N
    if j==N 
       S_part = [zeros((j-1) * size(F,1),size(E,2)) ;E];  
    else   
       S_part = F^(N-j) * E;
       for i = (N-j)-1:-1:0
           S_part = [F^(i) * E ;S_part];  
       end
       if i~=1
           S_part = [zeros((j-1) * size(F,1),size(E,2));S_part];
       end
    end
    if j==1
       S_mk = S_part;
    else
       S_mk = [S_mk S_part];
    end 
end

for j=1:N
    if j==N 
       D_part = [zeros((j-1) * size(F,1),size(B,2)) ;B];  
    else   
       D_part = F^(N-j) * B;
       for i = (N-j)-1:-1:0
           D_part = [F^(i) * B ;D_part];  
       end
       if i~=1
           D_part = [zeros((j-1) * size(F,1),size(B,2));D_part];
       end
    end
    if j==1
       D_mk = D_part;
    else
       D_mk = [D_mk D_part];
    end 
end

Hbar = H;
for i = 1 : N-1
Hbar = blkdiag(Hbar,H);
end
H_mk = Hbar * F_mk;
L_mk = Hbar * S_mk;
G_mk = Hbar * D_mk;

S_bar_mk = S_mk(dim_x*(N-1)+1:dim_x*N,:); 
D_bar_mk = D_mk(dim_x*(N-1)+1:dim_x*N,:); 

Q_mk=Q; 
R_mk=R;
for i=1:N-1
    Q_mk = blkdiag(Q_mk,Q);
    R_mk = blkdiag(R_mk,R);
end

PAI = G_mk * Q_mk * G_mk' + R_mk;
P = (H_mk' * PAI^(-1) * H_mk)^(-1);
T =  (H_mk' * PAI^(-1) * H_mk)^(-1) * H_mk' * PAI^(-1);

sum1 = ((F^0)') * (F^0);
for i =1 : N-1
    sum1 = sum1 + ((F^i)') * (F^i);
end

B1 = B;                        %% 用于构造FB B 数组
sum2 = ((F^0)') * B1 * eye(dim_w,dim_w * N);
for i =1 : N-1
    B1 = [(F^i) * B B1];
    sum2 = sum2 + ((F^i)') * B1 * eye(dim_w * (i + 1),dim_w * N);
end

B1 = B;                       
sum3 =  (B1 * eye(dim_w,dim_w * N))' * B1 * eye(dim_w,dim_w * N);
for i =1 : N-1
    B1 = [(F^i) * B  B1];
    sum3 = sum3 + (B1 * eye(dim_w * (i + 1),dim_w * N))' * (B1 * eye(dim_w * (i + 1),dim_w * N));
end


E1 = E;                        %% 用于构造FE E 数组
sum4 = ((F^0)') * E1 * eye(dim_u,dim_u * N);
for i =1 : N-1
    E1 = [(F^i) * E E1];
    sum4 = sum4 + ((F^i)') * E1 * eye(dim_u * (i + 1),dim_u * N);
end

B1 = B;
E1 = E;
sum5 = (B1 * eye(dim_w,dim_w * N))' * E1 * eye(dim_u,dim_u * N);
for i =1 :N-1
    B1 = [(F^i) * B B1];
    E1 = [(F^i) * E E1];
    sum5 = sum5 + (B1 * eye(dim_w * (i + 1),dim_w * N))' * E1 * eye(dim_u * (i + 1),dim_u * N);
end

B1 = B; 
sum6 = [-1 * theta_CRS * (F^0)';
        -1 * theta_CRS * (B1 * eye(dim_w,dim_w * N))'];
for i =1 :N-2
    B1 = [(F^i) * B B1];
    sum7 = [-1 * theta_CRS * (F^i)';
          -1 * theta_CRS * (B1 * eye(dim_w * (i + 1),dim_w * N))'];
    sum6 = [sum7 sum6];
end

 M11 = [(P^(-1)) + H_mk' * ((R_mk)^(-1)) * H_mk + theta_CRS * sum1       H_mk' * ((R_mk)^(-1)) * G_mk + theta_CRS * sum2;
        (H_mk' * ((R_mk)^(-1)) * G_mk + theta_CRS * sum2)'             ((Q_mk)^(-1)) + G_mk' * ((R_mk)^(-1)) * G_mk + theta_CRS * sum3];

M12 = [-1 * theta_CRS * (F^(N-1))';
       -1 * theta_CRS * D_bar_mk'];
M22 = [theta_CRS * eye(size((F^(N-1))',1),size((F^(N-1))',2))];

M13 = [-1 * (P^(-1)) * T - H_mk' * ((R_mk)^(-1)) (P^(-1)) * T * L_mk + H_mk' * ((R_mk)^(-1)) * L_mk + theta_CRS * sum4;
       -1 * G_mk' * ((R_mk)^(-1))  theta_CRS * sum5 + G_mk' * ((R_mk)^(-1)) * L_mk]; 
M13 = [sum6 M13];   
M23 = [zeros(size(M22,1),size(sum6 ,2)) zeros(size(M22,1),size(-1 * G_mk' * ((R_mk)^(-1)) ,2))   -1 * theta_CRS *  S_bar_mk];

N11 = [M11 M12;
       M12' M22];
N12 = [M13;M23];

beta = [zeros(dim_x,dim_x + N * dim_w) eye(dim_x)];           %% 取出解的下部分需要的系数

%  E1 = E; 
%  A1 = [F * x_IRS(:,s) + E1 * eye(dim_u,dim_u * N) * U ;Y;U];
%  for i=2:k-s-1
%  E1 = [(F^(i-1)) * E E1];    
%  A1 =[(F^i) * x_IRS(:,s)+ E1 * eye(dim_u * i,dim_u * N) * U ;A1];               %% 这边如果u 不全为0的话 要考虑Eu 
%  end


 A1 = [x_IRS(:,s);Y;U];
 for i=s+1:k-1  
 A1 =[x_IRS(:,i);A1];               %% 这边如果u 不全为0的话 要考虑Eu 
 end


 
if theta_CRS < 0
   [V1,D1] = eig(M11);
   PD1 = diag(D1);
   [V2,D2] = eig(M22 - M12' * (M11^(-1)) * M12);
   PD2 = diag(D2);
   if PD1>0  
       if PD2<0
          x_CRS = beta * (-1) * [M11 M12;M12' M22]^(-1) * [M13;M23] * A1;
       end
   end 
end

if theta_CRS > 0
   [V1,D1] = eig(N11);
   PD1 = diag(D1);
   if PD1>0
      x_CRS = beta * (-1) * N11^(-1) * N12 * A1;
   end 
end     
end