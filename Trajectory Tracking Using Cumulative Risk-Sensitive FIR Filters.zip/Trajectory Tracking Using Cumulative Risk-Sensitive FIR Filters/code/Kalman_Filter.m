function x_KF = Kalman_Filter(F,E,B,H,Init_P,Init_x,Q,R,y,u,t)                %%一次性求出所有时刻 估计值

for i=1:t 
    
    if i==1
     P_ = F * Init_P * F' +  B * Q * B'   ;  
     K = P_ * H' * (H * P_ * H' + R)^(-1);
     x_(:,i) = F * Init_x + E * u(:,i);
     x_KF(:,i) = x_(:,i)  + K * (y(:,i) - H * x_(:,i));   
     Init_P = (eye(size(K * H)) - K * H) * P_;
    else
    
     P_ = F * Init_P * F' +  B * Q * B'   ;     % 有两种：B * Q * B'  和   Q
    
     K = P_ * H' * (H * P_ * H' + R)^(-1);
    
     Init_P = (eye(size(K * H)) - K * H) * P_;
    
     x_(:,i) = F * x_KF(:,i-1) + E * u(:,i);
    
     x_KF(:,i) = x_(:,i) + K * (y(:,i) - H * x_(:,i));   
      
    end
end

end