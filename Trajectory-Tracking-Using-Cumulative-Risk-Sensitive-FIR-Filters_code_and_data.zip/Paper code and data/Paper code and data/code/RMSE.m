function RMsE = RMSE(xhat,x,StartTime,EndTime)
dim_x = size(xhat,1);
RMsE = size(dim_x,1);
for i=1:dim_x
    RMsE(i,:) =0;
    for j=StartTime:EndTime
        RMsE(i,:) = RMsE(i,:) + ( xhat(i,j)-x(i,j) )^2;
        if j==EndTime
           RMsE(i,:) = sqrt(RMsE(i,:)/(EndTime-StartTime+1));
        end
    end
end
end