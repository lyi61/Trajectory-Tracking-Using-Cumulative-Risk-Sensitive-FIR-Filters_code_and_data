%% -----------------Risk Sensitive filter------------------
%状态空间模型
%        x = Fx + Bw
%        y = Hx + v
%        z = Lx
%-----------------师姐代码---------------------------
%          RS_x_est=[10,10,10]';     
%          RS_P_pre=eye(d_x,d_x);   
%          RS_theta=-1;             
%          RS_W=eye(d_x,d_x);         
         
%          for k=1:steps
%              RS_x_pre=A*RS_x_est;            
%              RS_P_pre=A*pinv(inv(RS_P_pre)+C'*pinv(R)*C-RS_theta*RS_W)*A'+Q; 
%              RS_K=pinv(pinv(RS_P_pre)+C'*pinv(R)*C)*C'*pinv(R);
%              RS_x_est=RS_x_pre+RS_K*(Tru_Y(:,k)-C*RS_x_pre);
%              
%              RS_X_Est(:,k)=RS_x_est;
%              RS_X_Pre(:,k)=RS_x_pre;         
%          end

%%
function [x_hat,P] = RS_filter(F,H,B,L,Q,R,P,x_hat,y,theta)    
       K = (P^(-1) + H' * R^(-1) * H)^(-1) * H' * R^(-1);
       x_hat = F * x_hat + K * (y - H * F * x_hat);
       P = B * Q^(-1) * B' + F * (P^(-1) + H' * R^(-1) * H - theta * (L' * L))^(-1) *F';
end




