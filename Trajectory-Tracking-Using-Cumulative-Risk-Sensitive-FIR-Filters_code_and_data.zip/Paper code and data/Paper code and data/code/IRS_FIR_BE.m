%%
function x_IRS=IRS_FIR_BE(F,E,B,H,k,N,y,u,Q,R,theta)
dim_x = size(F,1);            %%x维数
dim_y = size(H,1);            %%y维数
dim_u = size(E,2);            %%u维数
dim_w = size(B,2);            %%w维数

m = k-N+1;
Y = [y(:,m)];
U = [u(:,m)];

for i = k-N+2:k                   %% 扩展状态空间方程参数
    Y = [Y ; y(:,i)];
    U = [U ; u(:,i)];
end

F_mk = F^0;
for i =1 : N-1
    F_mk = [F_mk ; F^i];
end

for j=1:N
    if j==N 
       S_part = [zeros((j-1) * size(F,1),size(E,2)) ;E];  
    else   
       S_part = F^(N-j) * E;
       for i = (N-j)-1:-1:0
           S_part = [F^(i) * E ;S_part];  
       end
       if i~=1
           S_part = [zeros((j-1) * size(F,1),size(E,2));S_part];
       end
    end
    if j==1
       S_mk = S_part;
    else
       S_mk = [S_mk S_part];
    end 
end

for j=1:N
    if j==N 
       D_part = [zeros((j-1) * size(F,1),size(B,2)) ;B];  
    else   
       D_part = F^(N-j) * B;
       for i = (N-j)-1:-1:0
           D_part = [F^(i) * B ;D_part];  
       end
       if i~=1
           D_part = [zeros((j-1) * size(F,1),size(B,2));D_part];
       end
    end
    if j==1
       D_mk = D_part;
    else
       D_mk = [D_mk D_part];
    end 
end

Hbar = H;
for i = 1 : N-1
Hbar = blkdiag(Hbar,H);
end
H_mk = Hbar * F_mk;
L_mk = Hbar * S_mk;
G_mk = Hbar * D_mk;

S_bar_mk = S_mk(dim_x*(N-1)+1:dim_x*N,:); 
D_bar_mk = D_mk(dim_x*(N-1)+1:dim_x*N,:); 

Q_mk=Q; 
R_mk=R;
for i=1:N-1
    Q_mk = blkdiag(Q_mk,Q);
    R_mk = blkdiag(R_mk,R);
end

PAI = G_mk * Q_mk * G_mk' + R_mk;
P = (H_mk' * PAI^(-1) * H_mk)^(-1);
T =  (H_mk' * PAI^(-1) * H_mk)^(-1) * H_mk' * PAI^(-1);

f = F^(N-1);
 M11 = [(P^(-1)) + H_mk' * ((R_mk)^(-1)) * H_mk + theta * (F^(N-1))' * F^(N-1)  H_mk' * ((R_mk)^(-1)) * G_mk + theta * (F^(N-1))' * D_bar_mk;
        (H_mk' * ((R_mk)^(-1)) * G_mk + theta * (F^(N-1))' * D_bar_mk)'  ((Q_mk)^(-1)) + G_mk' * ((R_mk)^(-1)) * G_mk + theta * D_bar_mk' * D_bar_mk];

M12 = [-1 * theta * (F^(N-1))';
       -1 * theta * D_bar_mk'];
M22 = [theta * eye(size((F^(N-1))',1),size((F^(N-1))',2))];
M13 = [-1 * (P^(-1)) * T - H_mk' * ((R_mk)^(-1)) (P^(-1)) * T * L_mk + H_mk' * ((R_mk)^(-1)) * L_mk + theta * (F^(N-1))' * S_bar_mk;
       -1 * G_mk' * ((R_mk)^(-1))  theta * D_bar_mk' * S_bar_mk + G_mk' * ((R_mk)^(-1)) * L_mk]; 
M23 = [zeros(size((F^(N-1))',1),size(-1 * G_mk' * ((R_mk)^(-1)),2))  -1 * theta * S_bar_mk];

    N11 = [(P^(-1)) + H_mk' * ((R_mk)^(-1)) * H_mk + theta * (F^(N-1))' * (F^(N-1))   H_mk' * ((R_mk)^(-1)) * G_mk + theta * (F^(N-1))' * D_bar_mk -1 * theta * (F^(N-1))';
         (H_mk' * ((R_mk)^(-1)) * G_mk + theta * (F^(N-1))' * D_bar_mk)'  ((Q_mk)^(-1)) + G_mk' * ((R_mk)^(-1)) * G_mk + theta * D_bar_mk' * D_bar_mk -1 * theta * D_bar_mk';
         -1 * theta * F^(N-1) -1 * theta * D_bar_mk theta * eye(size((F^(N-1))',1),size((F^(N-1))',2))];
% 这个M11地方 H_mk' * ((R_mk)^(-1)) * H_mk 和  theta * (F^(N-1))' * (F^(N-1)) 互换位置会导致数值变化

N12 = [-1 * (P^(-1)) * T - H_mk' * ((R_mk)^(-1)) (P^(-1)) * T * L_mk + H_mk' * ((R_mk)^(-1)) * L_mk + theta * (F^(N-1))' * S_bar_mk;
       -1 * G_mk' * ((R_mk)^(-1))  theta * D_bar_mk' * S_bar_mk + G_mk' * ((R_mk)^(-1)) * L_mk;
       zeros(size((F^(N-1))',1),size(-1 * G_mk' * ((R_mk)^(-1)),2))  -1 * theta * S_bar_mk]; 

beta = [zeros(dim_x,dim_x + N * dim_w) eye(dim_x)];           %% 取出解的下部分需要的系数


if theta < 0
   [V1,D1] = eig(M11);
   PD1 = diag(D1);
   [V2,D2] = eig(M22 - M12' * (M11^(-1)) * M12);
   PD2 = diag(D2);
   if PD1>0  
       if PD2<0
          x_IRS = beta * (-1) * [M11 M12;M12' M22]^(-1) * [M13;M23] * [Y;U];
       end
   end 
end

if theta > 0
   [V1,D1] = eig(N11);
   PD1 = diag(D1);
   if PD1>0
      x_IRS = beta * (-1) * N11^(-1) * N12 * [Y;U];
   end 
end     
end