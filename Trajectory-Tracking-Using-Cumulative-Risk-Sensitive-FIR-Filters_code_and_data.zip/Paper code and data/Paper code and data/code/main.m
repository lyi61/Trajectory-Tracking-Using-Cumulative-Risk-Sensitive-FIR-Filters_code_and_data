clc;
clear;
close all;    

t=161;
% t = 310;    
st = 1;                % 采样时间
F = [1 st 0 0  0 0;
     0 1  0 0  0 0;
     0 0  1 st 0 0;
     0 0  0 1  0 0;
     0 0  0 0  1 st;
     0 0  0 0  0 1];    % 状态转移矩阵
 E = zeros(6);  
 B = [(st^2)/2  0            0;
       st       0            0;
      0        (st^2)/2      0;
      0         st           0;
      0         0            (st^2)/2;
      0         0            st];        
                            
H = [1 0 0 0 0 0;
     0 0 1 0 0 0;
     0 0 0 0 1 0];                                        % 观测矩阵

dim_x = size(F,1);                                        % x维数
dim_y = size(H,1);                                        % y维数
dim_u = size(E,2);                                        % u维数
dim_w = size(B,2);                                        % w维数

u = zeros(dim_u,t);                                       % 输入值的存放数组                               % 估计值初始值
Init_x = zeros(dim_x,1);
Init_u = zeros(dim_u,1);                                  % 输入值初始值                                    
Init_P = eye(dim_x);                                      % 协方差矩阵初始值   

%% --------------------噪声生成--------------------------------
mq = [0;0;0];               
Q  = [1   0   0;
      0   1   0;
      0   0   1]*0.2; 
w =B * gauss_rnd(mq,Q,t);           %%系统噪声             
mr = [0  ;  0;   0];
R =  [1       0       0;
      0       1       0; 
      0       0       1]*0.8;
v = gauss_rnd(mr,R,t);           %%过程噪声

%% 导入真实值和测量值
lat1=xlsread('C:\Users\Administrator\Desktop\Paper code and data\Paper code and data\data\data1.xlsx','B2:B162');
lon1=xlsread('C:\Users\Administrator\Desktop\Paper code and data\Paper code and data\data\data1.xlsx','C2:C162');
alt1=xlsread('C:\Users\Administrator\Desktop\Paper code and data\Paper code and data\data\data1.xlsx','D2:D162');

lat2 = xlsread('C:\Users\Administrator\Desktop\Paper code and data\Paper code and data\data\data1.xlsx','F2:F162');
lon2 = xlsread('C:\Users\Administrator\Desktop\Paper code and data\Paper code and data\data\data1.xlsx','G2:G162');
alt2 = xlsread('C:\Users\Administrator\Desktop\Paper code and data\Paper code and data\data\data1.xlsx','H2:H162');






% lat1=xlsread('C:\Users\Administrator\Desktop\Paper code and data\Paper code and data\data\data2.xlsx','B2:B311');
% lon1=xlsread('C:\Users\Administrator\Desktop\Paper code and data\Paper code and data\data\data2.xlsx','C2:C311');
% alt1=xlsread('C:\Users\Administrator\Desktop\Paper code and data\Paper code and data\data\data2.xlsx','D2:D311');
% 
% lat2 = xlsread('C:\Users\Administrator\Desktop\Paper code and data\Paper code and data\data\data2.xlsx','F2:F311');
% lon2 = xlsread('C:\Users\Administrator\Desktop\Paper code and data\Paper code and data\data\data2.xlsx','G2:G311');
% alt2 = xlsread('C:\Users\Administrator\Desktop\Paper code and data\Paper code and data\data\data2.xlsx','H2:H311');




for i=1:t
   x(:,i) = lla2ecef([lat1(i),lon1(i),alt1(i)],'WGS84');
   y(:,i) = lla2ecef([lat2(i),lon2(i), alt2(i)], 'WGS84');
end


 for i=1:t
    x(:,i) =  x(:,i)-[-2743610.98046785;4702290.99128784;3311773.59029325];
    y(:,i) =  y(:,i)-[-2743610.98046785;4702290.99128784;3311773.59029325]-[1;-4;3];%50-210
 end


%  for i=1:t
%    x(:,i) =  x(:,i)- [-2744039.34214180;4702225.03539562;3311513.61675955];
%    y(:,i) =  y(:,i)-[-2744039.34214180;4702225.03539562;3311513.61675955]-[1;-4;3];
%  end

 
%% CRS
theta_CRS = -1;
theta_IRS = -1;
N_CRS = 13;
N_CIRS = 3;
tic;
for  k = N_CRS:t
     x_CRS_all(:,k) = CRS_FIR_BE_v2(F,E,B,H,Q,R,y,u,k,N_CRS,N_CIRS,theta_CRS,theta_IRS); 
end
timeCRS=toc;
x_CRS(1,:) = x_CRS_all(1,:);
x_CRS(2,:) = x_CRS_all(3,:);
x_CRS(3,:) = x_CRS_all(5,:);

%% KF
tic;
x_kf_all = Kalman_Filter(F,E,B,H,Init_P,Init_x,Q,R,y,u,t);
timeKF=toc;
x_KF(1,:) = x_kf_all(1,:);
x_KF(2,:) = x_kf_all(3,:);
x_KF(3,:) = x_kf_all(5,:);

 
%% RS        
x_RS_all(:,1) = Init_x;
P_RS  = Init_P;
theta = -1;
L = eye(dim_x);
tic
for  k = 2:t
[x_RS_all(:,k),P_RS] = RS_filter(F,H,B,L,Q,R,P_RS,x_RS_all(:,k-1),y(:,k),theta);
end
timeRS =toc;
x_RS(1,:) = x_RS_all(1,:);
x_RS(2,:) = x_RS_all(3,:);
x_RS(3,:) = x_RS_all(5,:);


%% UFIR
N_UFIR = 2;
tic
for  k = N_UFIR:t
     x_UFIR_all(:,k) = U_FIR_Filter(F,E,B,H,N_UFIR,y,u,k);
end
timeUFIR =toc;
x_UFIR(1,:) = x_UFIR_all(1,:);
x_UFIR(2,:) = x_UFIR_all(3,:);
x_UFIR(3,:) = x_UFIR_all(5,:);


figure;
subplot(3,1,1)
plot(N_CRS:t,x(1,N_CRS:t)-x_CRS(1,N_CRS:t),'-r');
hold on;
plot(x(1,1:t)-x_KF(1,1:t),'-b');
hold on;
plot(x(1,1:t)-x_RS(1,:),'-m')
hold on;
plot(N_UFIR:t,x(1,N_UFIR:t)-x_UFIR(1,N_UFIR:t),'-g')
hold on;
legend('CRSFIR','KF','RSF','UFIR');
xlim([1, t]);
xlabel('Time');
ylabel('Estimation error');
title('(a)');
subplot(3,1,2)
plot(N_CRS:t,x(2,N_CRS:t)-x_CRS(2,N_CRS:t),'-r');
hold on;
plot(x(2,1:t)-x_KF(2,1:t),'-b');
hold on;
plot(x(2,1:t)-x_RS(2,:),'-m')
hold on;
plot(N_UFIR:t,x(2,N_UFIR:t)-x_UFIR(2,N_UFIR:t),'-g')
hold on;
legend('CRSFIR','KF','RSF','UFIR');
xlim([1, t]);
xlabel('Time');
ylabel('Estimation error');
title('(b)');
subplot(3,1,3)
plot(N_CRS:t,x(3,N_CRS:t)-x_CRS(3,N_CRS:t),'-r');
hold on;
plot(x(3,1:t)-x_KF(3,1:t),'-b');
hold on;
plot(x(3,1:t)-x_RS(3,:),'-m')
hold on;
plot(N_UFIR:t,x(3,N_UFIR:t)-x_UFIR(3,N_UFIR:t),'-g')
hold on;
legend('CRSFIR','KF','RSF','UFIR');
xlim([1, t]);
xlabel('Time');
ylabel('Estimation error');
title('(c)');


figure;
plot(x_CRS(1,N_CRS:t),x_CRS(2,N_CRS:t),'-r');
hold on;
plot(x_KF(1,1:t),x_KF(2,1:t),'-b');
hold on;
plot(x_RS(1,1:t),x_RS(2,1:t),'-m');
hold on;
plot(x_UFIR(1,N_UFIR:t),x_UFIR(2,N_UFIR:t),'-g')
hold on;
plot(x(1,1:t),x(2,1:t),'-k');
hold on;
legend('CRSFIR','KF','RSF','UFIR','True');
xlabel('X');
ylabel('Y');

[RMSE(x_CRS,x,N_CRS,t) RMSE(x_KF,x,1,t) RMSE(x_RS,x,1,t) RMSE(x_UFIR,x,N_UFIR,t)]



